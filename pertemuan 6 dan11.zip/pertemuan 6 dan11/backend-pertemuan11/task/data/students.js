// TODO 1: Buat data students
// code here
const students = [
    "ririn", "apiz", "agas"
]

// TODO 2: export data students
// code here
module.exports = students;